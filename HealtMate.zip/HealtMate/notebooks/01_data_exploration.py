import pandas as pd
import joblib
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns


def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.4f}")

    conf_matrix = confusion_matrix(y_test, y_pred)
    print("Confusion Matrix:")
    print(conf_matrix)

    class_report = classification_report(y_test, y_pred)
    print("Classification Report:")
    print(class_report)

    return y_pred, conf_matrix, class_report


def plot_confusion_matrix(conf_matrix):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()


def classify_user_input(model, preprocessor):
    print("Please enter the new data for classification:")
    # Replace with actual feature names used during training
    feature_names = ['Feature1', 'Feature2', 'Feature3', 'Feature4']  # Update this list

    input_data = []
    for feature in feature_names:
        value = float(input(f"Enter value for {feature}: "))
        input_data.append(value)

    input_df = pd.DataFrame([input_data], columns=feature_names)

    # Apply the same preprocessing steps as done for training data
    input_df = preprocessor.transform(input_df)

    prediction = model.predict(input_df)
    print(f"The predicted class for the input data is: {prediction[0]}")


if __name__ == "__main__":
    # Adjust paths if necessary
    X_test = pd.read_csv('F:/HealthMate AI_Project/notebooks/data/processed/X_test.csv')
    y_test = pd.read_csv('F:/HealthMate AI_Project/notebooks/data/processed/y_test.csv')

    # Ensure y_test is categorical
    if y_test['Value'].dtype == 'float64' or y_test['Value'].dtype == 'int64':
        y_test['Value'] = pd.qcut(y_test['Value'], q=3, labels=[0, 1, 2])
    y_test = y_test['Value']  # Extract the 'Value' column for y_test

    # Load the trained model and preprocessor from the uploaded files
    model_path = 'F:/HealthMate AI_Project/notebooks/models/random_forest.joblib'
    model = joblib.load(model_path)
    preprocessor_path = 'F:/HealthMate AI_Project/notebooks/models/random_forest.joblib'
    preprocessor = joblib.load(preprocessor_path)

    y_pred, conf_matrix, class_report = evaluate_model(model, X_test, y_test)
    plot_confusion_matrix(conf_matrix)

    # Classify new data based on user input
    classify_user_input(model, preprocessor)
